# Monokai Kong

Sublime Text: 

	1. Open the packages folder by seelct: Prefereces -> Browse Packages
	2. Copy the file "Monokai Kong.tmTheme" into this folder

Visual Studio Code:
	1. Navigate to extension folder of Visual Studio Code
		- Windows: %USERPROFILE%\.vscode\extensions
		- macOS: ~/.vscode/extensions
		- Linux: ~/.vscode/extensions
	2. Copy the folder "Visual Studio Code" in the .ZIP file into this folder of extensions, and rename to "monokai-kong"
	3. Restart Visual Studio Code, select Preferences -> Color Theme, and search for "Monokai Kong"


	Happy coding!!!!!
	Quynh Nguyen (Mr.) - https://github.com/quynh-ng